# Design System Strategy: Cinematic Temporal Engineering

## 1. Overview & Creative North Star: "The Chronos Architect"
This design system is built for a 3D artist portfolio that treats time and space as tactile materials. The Creative North Star is **"The Chronos Architect"**—a vision where the UI does not just hold content but frames it within a high-fidelity, technical laboratory. 

To move beyond "template" portfolios, this system rejects the standard boxy layout in favor of **Intentional Asymmetry** and **Cinematic Depth**. Elements should feel like HUD (Heads-Up Display) components projected onto a dark, infinite void. We achieve this by utilizing extreme typographic contrast (massive display headers vs. microscopic technical labels) and a "Scanned" aesthetic using subtle grid overlays and glowing data points.

---

## 2. Colors & Visual Soul
The palette is rooted in a "Deep Space" void, punctured by high-energy light leaks.

*   **Primary Background (`#131315` / `surface`):** A heavy, ink-like base that allows accents to "bloom."
*   **The Accents:**
    *   **Primary (`#00f3ff`):** Use for technical data, "active" states, and laser-thin accents.
    *   **Secondary (`#7000ff`):** Use for depth and atmospheric glows.
    *   **Tertiary (`#ff0055` / `on_tertiary_container`):** Reserved for high-alert interactions or critical path highlights.

### The "No-Line" Rule
Traditional 1px solid borders are strictly prohibited. They feel "web-standard" and cheapen the cinematic experience. Instead:
*   **Tone Shifts:** Define sections by moving from `surface` to `surface_container_low`.
*   **Light Edges:** Use a 1px top-only gradient stroke that fades out, mimicking a light source hitting the top edge of a glass pane.

### The "Glass & Gradient" Rule
Floating elements (modals, navigation, or hovered cards) must utilize **Glassmorphism**. Use `surface_variant` at 40% opacity with a `20px` backdrop-blur. This creates a sense of "layered instrumentation" rather than flat panels.

---

## 3. Typography: Technical Editorial
We pair the brutalist, wide-set geometry of **Space Grotesk** (serving as our 'Orbitron' alternative) with the utilitarian precision of **Inter**.

*   **Display (Space Grotesk):** Use `display-lg` for project titles. Tracking should be tightened to `-0.05em` to feel like heavy machinery.
*   **Labels (Space Grotesk):** Use `label-sm` for technical metadata (e.g., "POLYCOUNT: 450K"). These should be in **ALL CAPS** with `0.1em` letter spacing to mimic HUD readouts.
*   **Body (Inter):** Use `body-md` for descriptions. Inter provides the necessary legibility against high-contrast backgrounds, ensuring the technical aesthetic doesn't hinder communication.

---

## 4. Elevation & Depth: Tonal Layering
In a futuristic UI, shadows aren't "shadows"—they are light occlusions.

*   **The Layering Principle:** 
    *   **Base:** `surface_dim` (#131315)
    *   **Sub-Section:** `surface_container_lowest` (#0e0e10)
    *   **Interactive Cards:** `surface_container` (#201f22)
*   **Ambient Shadows:** For floating 3D assets or modals, use a 60px blur shadow with a 6% opacity using the `primary` color (`#00f3ff`) instead of black. This creates a "glow" rather than a drop shadow.
*   **The Ghost Border:** If a boundary is required for accessibility, use `outline_variant` at 15% opacity. It should be barely perceptible—a "whisper" of a container.

---

## 5. Components

### Buttons (Tactile Triggers)
*   **Primary:** Solid `primary_container` (#00f3ff) with `on_primary` text. Use `0px` border radius (Sharp edges). Add a subtle outer glow using `primary` at 20% opacity.
*   **Secondary:** Ghost variant. No fill, `outline` border at 30% opacity, text in `primary`. On hover, fill with `primary` at 10% opacity.
*   **Interaction:** On click, buttons should "flicker" (0.1s opacity shift) to mimic a hardware interface.

### Input Fields (Data Entry)
*   **Styling:** Bottom-border only using `outline`. Labels must be `label-sm` and positioned above the input, never as placeholders.
*   **Focus State:** The bottom border transforms into a `primary` (#00f3ff) glow.

### Cards & Lists (The Gallery)
*   **Anti-Divider Rule:** Never use horizontal lines. Separate list items using `spacing-6` (2rem) and subtle background shifts between `surface_container_low` and `surface_container_high`.
*   **HUD Overlays:** Gallery cards should feature microscopic corner "bracket" icons in `primary` to reinforce the "scanned" aesthetic.

### Additional Component: The "Timeline Scrubber"
A custom slider component used for navigating project phases. Use a `primary` color line with a `tertiary` (#ff0055) "playhead" to denote the "Sculpting Time" concept.

---

## 6. Do's and Don'ts

### Do
*   **DO** use the `0px` Roundedness Scale religiously. Everything is sharp, machined, and precise.
*   **DO** use "Negative Space as Structure." Allow large gaps (`spacing-20`) between major sections to create a sense of vastness.
*   **DO** lean into "Glitch" transitions. When navigating between pages, a 100ms chromatic aberration effect reinforces the technical theme.

### Don't
*   **DON'T** use rounded corners (`border-radius`). It breaks the "high-end technical" immersion.
*   **DON'T** use standard blue/grey shadows. They look "SaaS," not "Cinematic Portfolio."
*   **DON'T** crowd the UI. If a screen feels busy, remove borders before removing content; let the typography do the heavy lifting.